﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.LabelCommand = New System.Windows.Forms.Label
        Me.Label40 = New System.Windows.Forms.Label
        Me.LabelSpecfile = New System.Windows.Forms.Label
        Me.Label41 = New System.Windows.Forms.Label
        Me.LabelMpafilename = New System.Windows.Forms.Label
        Me.Label37 = New System.Windows.Forms.Label
        Me.CommandDatasettings = New System.Windows.Forms.Button
        Me.TextChan = New System.Windows.Forms.TextBox
        Me.CommandGetspec = New System.Windows.Forms.Button
        Me.LabelCalpoints = New System.Windows.Forms.Label
        Me.Label35 = New System.Windows.Forms.Label
        Me.LabelActive = New System.Windows.Forms.Label
        Me.Label34 = New System.Windows.Forms.Label
        Me.LabelSmpts = New System.Windows.Forms.Label
        Me.Label33 = New System.Windows.Forms.Label
        Me.LabelCaluse = New System.Windows.Forms.Label
        Me.Label32 = New System.Windows.Forms.Label
        Me.LabelNregions = New System.Windows.Forms.Label
        Me.Label31 = New System.Windows.Forms.Label
        Me.LabelSephead = New System.Windows.Forms.Label
        Me.Label29 = New System.Windows.Forms.Label
        Me.LabelMpafmt = New System.Windows.Forms.Label
        Me.Label28 = New System.Windows.Forms.Label
        Me.LabelBitshift = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.LabelXdim = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.LabelOffset = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.LabelParam = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.LabelAutoinc = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.LabelFmt = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.LabelSavedata = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.LabelAddcal = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.LabelEventpreset = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.LabelRoimax = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.LabelRoimin = New System.Windows.Forms.Label
        Me.Label36 = New System.Windows.Forms.Label
        Me.LabelCftfak = New System.Windows.Forms.Label
        Me.Label38 = New System.Windows.Forms.Label
        Me.LabelRange = New System.Windows.Forms.Label
        Me.Label39 = New System.Windows.Forms.Label
        Me.CommandSetting = New System.Windows.Forms.Button
        Me.LabelMaxval = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.LabelLine13 = New System.Windows.Forms.Label
        Me.LabelLine12 = New System.Windows.Forms.Label
        Me.LabelLine11 = New System.Windows.Forms.Label
        Me.LabelLine10 = New System.Windows.Forms.Label
        Me.LabelLine9 = New System.Windows.Forms.Label
        Me.LabelLine8 = New System.Windows.Forms.Label
        Me.LabelLine7 = New System.Windows.Forms.Label
        Me.LabelLine6 = New System.Windows.Forms.Label
        Me.LabelLine5 = New System.Windows.Forms.Label
        Me.LabelLine4 = New System.Windows.Forms.Label
        Me.LabelLine3 = New System.Windows.Forms.Label
        Me.LabelLine2 = New System.Windows.Forms.Label
        Me.LabelLine1 = New System.Windows.Forms.Label
        Me.LabelLine0 = New System.Windows.Forms.Label
        Me.CommandGetstring = New System.Windows.Forms.Button
        Me.LabelSweeps = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.LabelRoirate = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.LabelRoisum = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.LabelTotalsum = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.LabelOfls = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.LabelRuntime = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.LabelStarted = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.CommandUpdate = New System.Windows.Forms.Button
        Me.TextRespons = New System.Windows.Forms.TextBox
        Me.TextCommand = New System.Windows.Forms.TextBox
        Me.CommandExecute = New System.Windows.Forms.Button
        Me.CommandSave = New System.Windows.Forms.Button
        Me.CommandErase = New System.Windows.Forms.Button
        Me.CommandContinue = New System.Windows.Forms.Button
        Me.CommandHalt = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.CommandStart = New System.Windows.Forms.Button
        Me.TextMC = New System.Windows.Forms.TextBox
        Me.LabelData23 = New System.Windows.Forms.Label
        Me.LabelData22 = New System.Windows.Forms.Label
        Me.LabelData21 = New System.Windows.Forms.Label
        Me.LabelData20 = New System.Windows.Forms.Label
        Me.LabelData19 = New System.Windows.Forms.Label
        Me.LabelData18 = New System.Windows.Forms.Label
        Me.LabelData17 = New System.Windows.Forms.Label
        Me.LabelData16 = New System.Windows.Forms.Label
        Me.LabelData15 = New System.Windows.Forms.Label
        Me.LabelData14 = New System.Windows.Forms.Label
        Me.LabelData13 = New System.Windows.Forms.Label
        Me.LabelData12 = New System.Windows.Forms.Label
        Me.LabelData11 = New System.Windows.Forms.Label
        Me.LabelData10 = New System.Windows.Forms.Label
        Me.LabelData9 = New System.Windows.Forms.Label
        Me.LabelData8 = New System.Windows.Forms.Label
        Me.LabelData7 = New System.Windows.Forms.Label
        Me.LabelData6 = New System.Windows.Forms.Label
        Me.LabelData5 = New System.Windows.Forms.Label
        Me.LabelData4 = New System.Windows.Forms.Label
        Me.LabelData3 = New System.Windows.Forms.Label
        Me.LabelData2 = New System.Windows.Forms.Label
        Me.LabelData1 = New System.Windows.Forms.Label
        Me.LabelData0 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.LabelStarts = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.LabelSweepmode = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.LabelPrena = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.LabelCycles = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.LabelSequences = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.LabelSyncout = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.LabelDigio = New System.Windows.Forms.Label
        Me.Label27 = New System.Windows.Forms.Label
        Me.LabelDigval = New System.Windows.Forms.Label
        Me.Label30 = New System.Windows.Forms.Label
        Me.LabelDac0 = New System.Windows.Forms.Label
        Me.Label42 = New System.Windows.Forms.Label
        Me.LabelDac1 = New System.Windows.Forms.Label
        Me.Label43 = New System.Windows.Forms.Label
        Me.LabelDac2 = New System.Windows.Forms.Label
        Me.Label44 = New System.Windows.Forms.Label
        Me.LabelDac3 = New System.Windows.Forms.Label
        Me.Label45 = New System.Windows.Forms.Label
        Me.LabelDac4 = New System.Windows.Forms.Label
        Me.Label46 = New System.Windows.Forms.Label
        Me.LabelDac5 = New System.Windows.Forms.Label
        Me.Label47 = New System.Windows.Forms.Label
        Me.LabelFdac = New System.Windows.Forms.Label
        Me.Label48 = New System.Windows.Forms.Label
        Me.LabelTagbits = New System.Windows.Forms.Label
        Me.Label49 = New System.Windows.Forms.Label
        Me.LabelExtclk = New System.Windows.Forms.Label
        Me.Label50 = New System.Windows.Forms.Label
        Me.LabelSerno = New System.Windows.Forms.Label
        Me.Label51 = New System.Windows.Forms.Label
        Me.LabelDdruse = New System.Windows.Forms.Label
        Me.Label52 = New System.Windows.Forms.Label
        Me.LabelHoldafter = New System.Windows.Forms.Label
        Me.Label53 = New System.Windows.Forms.Label
        Me.LabelSwpreset = New System.Windows.Forms.Label
        Me.Label55 = New System.Windows.Forms.Label
        Me.LabelFstchan = New System.Windows.Forms.Label
        Me.Label56 = New System.Windows.Forms.Label
        Me.LabelTimepreset = New System.Windows.Forms.Label
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'LabelCommand
        '
        Me.LabelCommand.AutoSize = True
        Me.LabelCommand.Location = New System.Drawing.Point(677, 513)
        Me.LabelCommand.Name = "LabelCommand"
        Me.LabelCommand.Size = New System.Drawing.Size(67, 13)
        Me.LabelCommand.TabIndex = 314
        Me.LabelCommand.Text = "                  _"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(602, 513)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(57, 13)
        Me.Label40.TabIndex = 313
        Me.Label40.Text = "Command:"
        '
        'LabelSpecfile
        '
        Me.LabelSpecfile.AutoSize = True
        Me.LabelSpecfile.Location = New System.Drawing.Point(677, 500)
        Me.LabelSpecfile.Name = "LabelSpecfile"
        Me.LabelSpecfile.Size = New System.Drawing.Size(67, 13)
        Me.LabelSpecfile.TabIndex = 312
        Me.LabelSpecfile.Text = "                  _"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(602, 500)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(48, 13)
        Me.Label41.TabIndex = 311
        Me.Label41.Text = "Specfile:"
        '
        'LabelMpafilename
        '
        Me.LabelMpafilename.AutoSize = True
        Me.LabelMpafilename.Location = New System.Drawing.Point(677, 487)
        Me.LabelMpafilename.Name = "LabelMpafilename"
        Me.LabelMpafilename.Size = New System.Drawing.Size(67, 13)
        Me.LabelMpafilename.TabIndex = 310
        Me.LabelMpafilename.Text = "                  _"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(602, 487)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(52, 13)
        Me.Label37.TabIndex = 309
        Me.Label37.Text = "Filename:"
        '
        'CommandDatasettings
        '
        Me.CommandDatasettings.Location = New System.Drawing.Point(595, 371)
        Me.CommandDatasettings.Name = "CommandDatasettings"
        Me.CommandDatasettings.Size = New System.Drawing.Size(139, 24)
        Me.CommandDatasettings.TabIndex = 308
        Me.CommandDatasettings.Text = "Get Datasettings"
        Me.CommandDatasettings.UseVisualStyleBackColor = True
        '
        'TextChan
        '
        Me.TextChan.Location = New System.Drawing.Point(595, 41)
        Me.TextChan.Name = "TextChan"
        Me.TextChan.Size = New System.Drawing.Size(48, 20)
        Me.TextChan.TabIndex = 307
        Me.TextChan.Text = "0"
        '
        'CommandGetspec
        '
        Me.CommandGetspec.Location = New System.Drawing.Point(595, 12)
        Me.CommandGetspec.Name = "CommandGetspec"
        Me.CommandGetspec.Size = New System.Drawing.Size(139, 24)
        Me.CommandGetspec.TabIndex = 306
        Me.CommandGetspec.Text = "Get Spectrum"
        Me.CommandGetspec.UseVisualStyleBackColor = True
        '
        'LabelCalpoints
        '
        Me.LabelCalpoints.AutoSize = True
        Me.LabelCalpoints.Location = New System.Drawing.Point(501, 124)
        Me.LabelCalpoints.Name = "LabelCalpoints"
        Me.LabelCalpoints.Size = New System.Drawing.Size(67, 13)
        Me.LabelCalpoints.TabIndex = 305
        Me.LabelCalpoints.Text = "                  0"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(426, 124)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(53, 13)
        Me.Label35.TabIndex = 304
        Me.Label35.Text = "Calpoints:"
        '
        'LabelActive
        '
        Me.LabelActive.AutoSize = True
        Me.LabelActive.Location = New System.Drawing.Point(501, 189)
        Me.LabelActive.Name = "LabelActive"
        Me.LabelActive.Size = New System.Drawing.Size(67, 13)
        Me.LabelActive.TabIndex = 303
        Me.LabelActive.Text = "                  0"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(426, 189)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(40, 13)
        Me.Label34.TabIndex = 302
        Me.Label34.Text = "Active:"
        '
        'LabelSmpts
        '
        Me.LabelSmpts.AutoSize = True
        Me.LabelSmpts.Location = New System.Drawing.Point(677, 461)
        Me.LabelSmpts.Name = "LabelSmpts"
        Me.LabelSmpts.Size = New System.Drawing.Size(67, 13)
        Me.LabelSmpts.TabIndex = 301
        Me.LabelSmpts.Text = "                  0"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(602, 461)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(39, 13)
        Me.Label33.TabIndex = 300
        Me.Label33.Text = "Smpts:"
        '
        'LabelCaluse
        '
        Me.LabelCaluse.AutoSize = True
        Me.LabelCaluse.Location = New System.Drawing.Point(501, 110)
        Me.LabelCaluse.Name = "LabelCaluse"
        Me.LabelCaluse.Size = New System.Drawing.Size(67, 13)
        Me.LabelCaluse.TabIndex = 299
        Me.LabelCaluse.Text = "                  0"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(426, 110)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(42, 13)
        Me.Label32.TabIndex = 298
        Me.Label32.Text = "Caluse:"
        '
        'LabelNregions
        '
        Me.LabelNregions.AutoSize = True
        Me.LabelNregions.Location = New System.Drawing.Point(501, 97)
        Me.LabelNregions.Name = "LabelNregions"
        Me.LabelNregions.Size = New System.Drawing.Size(67, 13)
        Me.LabelNregions.TabIndex = 297
        Me.LabelNregions.Text = "                  0"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(426, 97)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(52, 13)
        Me.Label31.TabIndex = 296
        Me.Label31.Text = "Nregions:"
        '
        'LabelSephead
        '
        Me.LabelSephead.AutoSize = True
        Me.LabelSephead.Location = New System.Drawing.Point(677, 448)
        Me.LabelSephead.Name = "LabelSephead"
        Me.LabelSephead.Size = New System.Drawing.Size(67, 13)
        Me.LabelSephead.TabIndex = 293
        Me.LabelSephead.Text = "                  0"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(602, 448)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(53, 13)
        Me.Label29.TabIndex = 292
        Me.Label29.Text = "Sephead:"
        '
        'LabelMpafmt
        '
        Me.LabelMpafmt.AutoSize = True
        Me.LabelMpafmt.Location = New System.Drawing.Point(677, 435)
        Me.LabelMpafmt.Name = "LabelMpafmt"
        Me.LabelMpafmt.Size = New System.Drawing.Size(67, 13)
        Me.LabelMpafmt.TabIndex = 291
        Me.LabelMpafmt.Text = "                  0"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(602, 435)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(45, 13)
        Me.Label28.TabIndex = 290
        Me.Label28.Text = "Mpafmt:"
        '
        'LabelBitshift
        '
        Me.LabelBitshift.AutoSize = True
        Me.LabelBitshift.Location = New System.Drawing.Point(501, 176)
        Me.LabelBitshift.Name = "LabelBitshift"
        Me.LabelBitshift.Size = New System.Drawing.Size(67, 13)
        Me.LabelBitshift.TabIndex = 285
        Me.LabelBitshift.Text = "                  0"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(426, 176)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(41, 13)
        Me.Label25.TabIndex = 284
        Me.Label25.Text = "Bitshift:"
        '
        'LabelXdim
        '
        Me.LabelXdim.AutoSize = True
        Me.LabelXdim.Location = New System.Drawing.Point(501, 163)
        Me.LabelXdim.Name = "LabelXdim"
        Me.LabelXdim.Size = New System.Drawing.Size(67, 13)
        Me.LabelXdim.TabIndex = 283
        Me.LabelXdim.Text = "                  0"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(426, 163)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(33, 13)
        Me.Label24.TabIndex = 282
        Me.Label24.Text = "Xdim:"
        '
        'LabelOffset
        '
        Me.LabelOffset.AutoSize = True
        Me.LabelOffset.Location = New System.Drawing.Point(501, 150)
        Me.LabelOffset.Name = "LabelOffset"
        Me.LabelOffset.Size = New System.Drawing.Size(67, 13)
        Me.LabelOffset.TabIndex = 281
        Me.LabelOffset.Text = "                  0"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(426, 150)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(38, 13)
        Me.Label23.TabIndex = 280
        Me.Label23.Text = "Offset:"
        '
        'LabelParam
        '
        Me.LabelParam.AutoSize = True
        Me.LabelParam.Location = New System.Drawing.Point(501, 137)
        Me.LabelParam.Name = "LabelParam"
        Me.LabelParam.Size = New System.Drawing.Size(67, 13)
        Me.LabelParam.TabIndex = 279
        Me.LabelParam.Text = "                  0"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(426, 137)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(40, 13)
        Me.Label22.TabIndex = 278
        Me.Label22.Text = "Param:"
        '
        'LabelAutoinc
        '
        Me.LabelAutoinc.AutoSize = True
        Me.LabelAutoinc.Location = New System.Drawing.Point(677, 409)
        Me.LabelAutoinc.Name = "LabelAutoinc"
        Me.LabelAutoinc.Size = New System.Drawing.Size(67, 13)
        Me.LabelAutoinc.TabIndex = 277
        Me.LabelAutoinc.Text = "                  0"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(602, 409)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(46, 13)
        Me.Label21.TabIndex = 276
        Me.Label21.Text = "Autoinc:"
        '
        'LabelFmt
        '
        Me.LabelFmt.AutoSize = True
        Me.LabelFmt.Location = New System.Drawing.Point(677, 422)
        Me.LabelFmt.Name = "LabelFmt"
        Me.LabelFmt.Size = New System.Drawing.Size(67, 13)
        Me.LabelFmt.TabIndex = 275
        Me.LabelFmt.Text = "                  0"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(602, 422)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(27, 13)
        Me.Label20.TabIndex = 274
        Me.Label20.Text = "Fmt:"
        '
        'LabelSavedata
        '
        Me.LabelSavedata.AutoSize = True
        Me.LabelSavedata.Location = New System.Drawing.Point(677, 396)
        Me.LabelSavedata.Name = "LabelSavedata"
        Me.LabelSavedata.Size = New System.Drawing.Size(67, 13)
        Me.LabelSavedata.TabIndex = 273
        Me.LabelSavedata.Text = "                  0"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(602, 396)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(56, 13)
        Me.Label19.TabIndex = 272
        Me.Label19.Text = "Savedata:"
        '
        'LabelAddcal
        '
        Me.LabelAddcal.AutoSize = True
        Me.LabelAddcal.Location = New System.Drawing.Point(677, 474)
        Me.LabelAddcal.Name = "LabelAddcal"
        Me.LabelAddcal.Size = New System.Drawing.Size(67, 13)
        Me.LabelAddcal.TabIndex = 271
        Me.LabelAddcal.Text = "                  0"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(602, 474)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(42, 13)
        Me.Label18.TabIndex = 270
        Me.Label18.Text = "Caluse:"
        '
        'LabelEventpreset
        '
        Me.LabelEventpreset.AutoSize = True
        Me.LabelEventpreset.Location = New System.Drawing.Point(501, 202)
        Me.LabelEventpreset.Name = "LabelEventpreset"
        Me.LabelEventpreset.Size = New System.Drawing.Size(67, 13)
        Me.LabelEventpreset.TabIndex = 269
        Me.LabelEventpreset.Text = "                  0"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(426, 202)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(67, 13)
        Me.Label17.TabIndex = 268
        Me.Label17.Text = "Eventpreset:"
        '
        'LabelRoimax
        '
        Me.LabelRoimax.AutoSize = True
        Me.LabelRoimax.Location = New System.Drawing.Point(501, 84)
        Me.LabelRoimax.Name = "LabelRoimax"
        Me.LabelRoimax.Size = New System.Drawing.Size(67, 13)
        Me.LabelRoimax.TabIndex = 267
        Me.LabelRoimax.Text = "                  0"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(426, 84)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(45, 13)
        Me.Label16.TabIndex = 266
        Me.Label16.Text = "Roimax:"
        '
        'LabelRoimin
        '
        Me.LabelRoimin.AutoSize = True
        Me.LabelRoimin.Location = New System.Drawing.Point(501, 71)
        Me.LabelRoimin.Name = "LabelRoimin"
        Me.LabelRoimin.Size = New System.Drawing.Size(67, 13)
        Me.LabelRoimin.TabIndex = 265
        Me.LabelRoimin.Text = "                  0"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(426, 71)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(42, 13)
        Me.Label36.TabIndex = 264
        Me.Label36.Text = "Roimin:"
        '
        'LabelCftfak
        '
        Me.LabelCftfak.AutoSize = True
        Me.LabelCftfak.Location = New System.Drawing.Point(501, 57)
        Me.LabelCftfak.Name = "LabelCftfak"
        Me.LabelCftfak.Size = New System.Drawing.Size(67, 13)
        Me.LabelCftfak.TabIndex = 263
        Me.LabelCftfak.Text = "                  0"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(426, 57)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(38, 13)
        Me.Label38.TabIndex = 262
        Me.Label38.Text = "Cftfak:"
        '
        'LabelRange
        '
        Me.LabelRange.AutoSize = True
        Me.LabelRange.Location = New System.Drawing.Point(501, 44)
        Me.LabelRange.Name = "LabelRange"
        Me.LabelRange.Size = New System.Drawing.Size(67, 13)
        Me.LabelRange.TabIndex = 261
        Me.LabelRange.Text = "                  0"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(426, 44)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(42, 13)
        Me.Label39.TabIndex = 260
        Me.Label39.Text = "Range:"
        '
        'CommandSetting
        '
        Me.CommandSetting.Location = New System.Drawing.Point(419, 12)
        Me.CommandSetting.Name = "CommandSetting"
        Me.CommandSetting.Size = New System.Drawing.Size(139, 24)
        Me.CommandSetting.TabIndex = 259
        Me.CommandSetting.Text = "Update Setting"
        Me.CommandSetting.UseVisualStyleBackColor = True
        '
        'LabelMaxval
        '
        Me.LabelMaxval.AutoSize = True
        Me.LabelMaxval.Location = New System.Drawing.Point(221, 57)
        Me.LabelMaxval.Name = "LabelMaxval"
        Me.LabelMaxval.Size = New System.Drawing.Size(67, 13)
        Me.LabelMaxval.TabIndex = 246
        Me.LabelMaxval.Text = "                  0"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(147, 57)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 13)
        Me.Label2.TabIndex = 245
        Me.Label2.Text = "Maxval:"
        '
        'LabelLine13
        '
        Me.LabelLine13.AutoSize = True
        Me.LabelLine13.Location = New System.Drawing.Point(223, 395)
        Me.LabelLine13.Name = "LabelLine13"
        Me.LabelLine13.Size = New System.Drawing.Size(49, 13)
        Me.LabelLine13.TabIndex = 244
        Me.LabelLine13.Text = "Filename"
        '
        'LabelLine12
        '
        Me.LabelLine12.AutoSize = True
        Me.LabelLine12.Location = New System.Drawing.Point(223, 372)
        Me.LabelLine12.Name = "LabelLine12"
        Me.LabelLine12.Size = New System.Drawing.Size(39, 13)
        Me.LabelLine12.TabIndex = 243
        Me.LabelLine12.Text = "Line12"
        '
        'LabelLine11
        '
        Me.LabelLine11.AutoSize = True
        Me.LabelLine11.Location = New System.Drawing.Point(223, 359)
        Me.LabelLine11.Name = "LabelLine11"
        Me.LabelLine11.Size = New System.Drawing.Size(39, 13)
        Me.LabelLine11.TabIndex = 242
        Me.LabelLine11.Text = "Line11"
        '
        'LabelLine10
        '
        Me.LabelLine10.AutoSize = True
        Me.LabelLine10.Location = New System.Drawing.Point(223, 346)
        Me.LabelLine10.Name = "LabelLine10"
        Me.LabelLine10.Size = New System.Drawing.Size(39, 13)
        Me.LabelLine10.TabIndex = 241
        Me.LabelLine10.Text = "Line10"
        '
        'LabelLine9
        '
        Me.LabelLine9.AutoSize = True
        Me.LabelLine9.Location = New System.Drawing.Point(223, 333)
        Me.LabelLine9.Name = "LabelLine9"
        Me.LabelLine9.Size = New System.Drawing.Size(33, 13)
        Me.LabelLine9.TabIndex = 240
        Me.LabelLine9.Text = "Line9"
        '
        'LabelLine8
        '
        Me.LabelLine8.AutoSize = True
        Me.LabelLine8.Location = New System.Drawing.Point(223, 320)
        Me.LabelLine8.Name = "LabelLine8"
        Me.LabelLine8.Size = New System.Drawing.Size(33, 13)
        Me.LabelLine8.TabIndex = 239
        Me.LabelLine8.Text = "Line8"
        '
        'LabelLine7
        '
        Me.LabelLine7.AutoSize = True
        Me.LabelLine7.Location = New System.Drawing.Point(223, 307)
        Me.LabelLine7.Name = "LabelLine7"
        Me.LabelLine7.Size = New System.Drawing.Size(33, 13)
        Me.LabelLine7.TabIndex = 238
        Me.LabelLine7.Text = "Line7"
        '
        'LabelLine6
        '
        Me.LabelLine6.AutoSize = True
        Me.LabelLine6.Location = New System.Drawing.Point(223, 294)
        Me.LabelLine6.Name = "LabelLine6"
        Me.LabelLine6.Size = New System.Drawing.Size(33, 13)
        Me.LabelLine6.TabIndex = 237
        Me.LabelLine6.Text = "Line6"
        '
        'LabelLine5
        '
        Me.LabelLine5.AutoSize = True
        Me.LabelLine5.Location = New System.Drawing.Point(223, 281)
        Me.LabelLine5.Name = "LabelLine5"
        Me.LabelLine5.Size = New System.Drawing.Size(33, 13)
        Me.LabelLine5.TabIndex = 236
        Me.LabelLine5.Text = "Line5"
        '
        'LabelLine4
        '
        Me.LabelLine4.AutoSize = True
        Me.LabelLine4.Location = New System.Drawing.Point(223, 268)
        Me.LabelLine4.Name = "LabelLine4"
        Me.LabelLine4.Size = New System.Drawing.Size(33, 13)
        Me.LabelLine4.TabIndex = 235
        Me.LabelLine4.Text = "Line4"
        '
        'LabelLine3
        '
        Me.LabelLine3.AutoSize = True
        Me.LabelLine3.Location = New System.Drawing.Point(223, 255)
        Me.LabelLine3.Name = "LabelLine3"
        Me.LabelLine3.Size = New System.Drawing.Size(33, 13)
        Me.LabelLine3.TabIndex = 234
        Me.LabelLine3.Text = "Line3"
        '
        'LabelLine2
        '
        Me.LabelLine2.AutoSize = True
        Me.LabelLine2.Location = New System.Drawing.Point(223, 242)
        Me.LabelLine2.Name = "LabelLine2"
        Me.LabelLine2.Size = New System.Drawing.Size(33, 13)
        Me.LabelLine2.TabIndex = 233
        Me.LabelLine2.Text = "Line2"
        '
        'LabelLine1
        '
        Me.LabelLine1.AutoSize = True
        Me.LabelLine1.Location = New System.Drawing.Point(223, 229)
        Me.LabelLine1.Name = "LabelLine1"
        Me.LabelLine1.Size = New System.Drawing.Size(33, 13)
        Me.LabelLine1.TabIndex = 232
        Me.LabelLine1.Text = "Line1"
        '
        'LabelLine0
        '
        Me.LabelLine0.AutoSize = True
        Me.LabelLine0.Location = New System.Drawing.Point(223, 216)
        Me.LabelLine0.Name = "LabelLine0"
        Me.LabelLine0.Size = New System.Drawing.Size(33, 13)
        Me.LabelLine0.TabIndex = 231
        Me.LabelLine0.Text = "Line0"
        '
        'CommandGetstring
        '
        Me.CommandGetstring.Location = New System.Drawing.Point(220, 177)
        Me.CommandGetstring.Name = "CommandGetstring"
        Me.CommandGetstring.Size = New System.Drawing.Size(139, 24)
        Me.CommandGetstring.TabIndex = 230
        Me.CommandGetstring.Text = "Get Strings"
        Me.CommandGetstring.UseVisualStyleBackColor = True
        '
        'LabelSweeps
        '
        Me.LabelSweeps.AutoSize = True
        Me.LabelSweeps.Location = New System.Drawing.Point(221, 137)
        Me.LabelSweeps.Name = "LabelSweeps"
        Me.LabelSweeps.Size = New System.Drawing.Size(67, 13)
        Me.LabelSweeps.TabIndex = 229
        Me.LabelSweeps.Text = "                  0"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(147, 137)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(48, 13)
        Me.Label9.TabIndex = 228
        Me.Label9.Text = "Sweeps:"
        '
        'LabelRoirate
        '
        Me.LabelRoirate.AutoSize = True
        Me.LabelRoirate.Location = New System.Drawing.Point(221, 123)
        Me.LabelRoirate.Name = "LabelRoirate"
        Me.LabelRoirate.Size = New System.Drawing.Size(67, 13)
        Me.LabelRoirate.TabIndex = 227
        Me.LabelRoirate.Text = "                  0"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(147, 123)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(44, 13)
        Me.Label8.TabIndex = 226
        Me.Label8.Text = "Roirate:"
        '
        'LabelRoisum
        '
        Me.LabelRoisum.AutoSize = True
        Me.LabelRoisum.Location = New System.Drawing.Point(221, 110)
        Me.LabelRoisum.Name = "LabelRoisum"
        Me.LabelRoisum.Size = New System.Drawing.Size(67, 13)
        Me.LabelRoisum.TabIndex = 225
        Me.LabelRoisum.Text = "                  0"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(147, 110)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(45, 13)
        Me.Label7.TabIndex = 224
        Me.Label7.Text = "Roisum:"
        '
        'LabelTotalsum
        '
        Me.LabelTotalsum.AutoSize = True
        Me.LabelTotalsum.Location = New System.Drawing.Point(221, 96)
        Me.LabelTotalsum.Name = "LabelTotalsum"
        Me.LabelTotalsum.Size = New System.Drawing.Size(67, 13)
        Me.LabelTotalsum.TabIndex = 223
        Me.LabelTotalsum.Text = "                  0"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(146, 96)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(53, 13)
        Me.Label6.TabIndex = 222
        Me.Label6.Text = "Totalsum:"
        '
        'LabelOfls
        '
        Me.LabelOfls.AutoSize = True
        Me.LabelOfls.Location = New System.Drawing.Point(221, 83)
        Me.LabelOfls.Name = "LabelOfls"
        Me.LabelOfls.Size = New System.Drawing.Size(67, 13)
        Me.LabelOfls.TabIndex = 221
        Me.LabelOfls.Text = "                  0"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(147, 83)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(28, 13)
        Me.Label5.TabIndex = 220
        Me.Label5.Text = "Ofls:"
        '
        'LabelRuntime
        '
        Me.LabelRuntime.AutoSize = True
        Me.LabelRuntime.Location = New System.Drawing.Point(221, 70)
        Me.LabelRuntime.Name = "LabelRuntime"
        Me.LabelRuntime.Size = New System.Drawing.Size(67, 13)
        Me.LabelRuntime.TabIndex = 219
        Me.LabelRuntime.Text = "                  0"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(146, 70)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(49, 13)
        Me.Label4.TabIndex = 218
        Me.Label4.Text = "Runtime:"
        '
        'LabelStarted
        '
        Me.LabelStarted.AutoSize = True
        Me.LabelStarted.Location = New System.Drawing.Point(221, 44)
        Me.LabelStarted.Name = "LabelStarted"
        Me.LabelStarted.Size = New System.Drawing.Size(67, 13)
        Me.LabelStarted.TabIndex = 217
        Me.LabelStarted.Text = "                  0"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(146, 44)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 13)
        Me.Label3.TabIndex = 216
        Me.Label3.Text = "Started:"
        '
        'CommandUpdate
        '
        Me.CommandUpdate.Location = New System.Drawing.Point(149, 12)
        Me.CommandUpdate.Name = "CommandUpdate"
        Me.CommandUpdate.Size = New System.Drawing.Size(139, 24)
        Me.CommandUpdate.TabIndex = 215
        Me.CommandUpdate.Text = "Update Status"
        Me.CommandUpdate.UseVisualStyleBackColor = True
        '
        'TextRespons
        '
        Me.TextRespons.Location = New System.Drawing.Point(23, 392)
        Me.TextRespons.Name = "TextRespons"
        Me.TextRespons.Size = New System.Drawing.Size(192, 20)
        Me.TextRespons.TabIndex = 214
        '
        'TextCommand
        '
        Me.TextCommand.Location = New System.Drawing.Point(24, 366)
        Me.TextCommand.Name = "TextCommand"
        Me.TextCommand.Size = New System.Drawing.Size(192, 20)
        Me.TextCommand.TabIndex = 213
        Me.TextCommand.Text = "RUN TEST.CTL"
        '
        'CommandExecute
        '
        Me.CommandExecute.Location = New System.Drawing.Point(24, 336)
        Me.CommandExecute.Name = "CommandExecute"
        Me.CommandExecute.Size = New System.Drawing.Size(76, 24)
        Me.CommandExecute.TabIndex = 212
        Me.CommandExecute.Text = "E&xecute"
        Me.CommandExecute.UseVisualStyleBackColor = True
        '
        'CommandSave
        '
        Me.CommandSave.Location = New System.Drawing.Point(24, 237)
        Me.CommandSave.Name = "CommandSave"
        Me.CommandSave.Size = New System.Drawing.Size(76, 24)
        Me.CommandSave.TabIndex = 211
        Me.CommandSave.Text = "S&ave"
        Me.CommandSave.UseVisualStyleBackColor = True
        '
        'CommandErase
        '
        Me.CommandErase.Location = New System.Drawing.Point(24, 207)
        Me.CommandErase.Name = "CommandErase"
        Me.CommandErase.Size = New System.Drawing.Size(76, 24)
        Me.CommandErase.TabIndex = 210
        Me.CommandErase.Text = "&Erase"
        Me.CommandErase.UseVisualStyleBackColor = True
        '
        'CommandContinue
        '
        Me.CommandContinue.Location = New System.Drawing.Point(24, 177)
        Me.CommandContinue.Name = "CommandContinue"
        Me.CommandContinue.Size = New System.Drawing.Size(76, 24)
        Me.CommandContinue.TabIndex = 209
        Me.CommandContinue.Text = "&Continue"
        Me.CommandContinue.UseVisualStyleBackColor = True
        '
        'CommandHalt
        '
        Me.CommandHalt.Location = New System.Drawing.Point(24, 147)
        Me.CommandHalt.Name = "CommandHalt"
        Me.CommandHalt.Size = New System.Drawing.Size(76, 24)
        Me.CommandHalt.TabIndex = 208
        Me.CommandHalt.Text = "&Halt"
        Me.CommandHalt.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(299, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(33, 13)
        Me.Label1.TabIndex = 207
        Me.Label1.Text = "Chn#"
        '
        'CommandStart
        '
        Me.CommandStart.Location = New System.Drawing.Point(24, 117)
        Me.CommandStart.Name = "CommandStart"
        Me.CommandStart.Size = New System.Drawing.Size(76, 24)
        Me.CommandStart.TabIndex = 206
        Me.CommandStart.Text = "&Start"
        Me.CommandStart.UseVisualStyleBackColor = True
        '
        'TextMC
        '
        Me.TextMC.Location = New System.Drawing.Point(339, 12)
        Me.TextMC.Name = "TextMC"
        Me.TextMC.Size = New System.Drawing.Size(48, 20)
        Me.TextMC.TabIndex = 205
        Me.TextMC.Text = "1"
        '
        'LabelData23
        '
        Me.LabelData23.AutoSize = True
        Me.LabelData23.Location = New System.Drawing.Point(667, 345)
        Me.LabelData23.Name = "LabelData23"
        Me.LabelData23.Size = New System.Drawing.Size(67, 13)
        Me.LabelData23.TabIndex = 338
        Me.LabelData23.Text = "                  0"
        '
        'LabelData22
        '
        Me.LabelData22.AutoSize = True
        Me.LabelData22.Location = New System.Drawing.Point(667, 332)
        Me.LabelData22.Name = "LabelData22"
        Me.LabelData22.Size = New System.Drawing.Size(67, 13)
        Me.LabelData22.TabIndex = 337
        Me.LabelData22.Text = "                  0"
        '
        'LabelData21
        '
        Me.LabelData21.AutoSize = True
        Me.LabelData21.Location = New System.Drawing.Point(667, 319)
        Me.LabelData21.Name = "LabelData21"
        Me.LabelData21.Size = New System.Drawing.Size(67, 13)
        Me.LabelData21.TabIndex = 336
        Me.LabelData21.Text = "                  0"
        '
        'LabelData20
        '
        Me.LabelData20.AutoSize = True
        Me.LabelData20.Location = New System.Drawing.Point(667, 306)
        Me.LabelData20.Name = "LabelData20"
        Me.LabelData20.Size = New System.Drawing.Size(67, 13)
        Me.LabelData20.TabIndex = 335
        Me.LabelData20.Text = "                  0"
        '
        'LabelData19
        '
        Me.LabelData19.AutoSize = True
        Me.LabelData19.Location = New System.Drawing.Point(667, 293)
        Me.LabelData19.Name = "LabelData19"
        Me.LabelData19.Size = New System.Drawing.Size(67, 13)
        Me.LabelData19.TabIndex = 334
        Me.LabelData19.Text = "                  0"
        '
        'LabelData18
        '
        Me.LabelData18.AutoSize = True
        Me.LabelData18.Location = New System.Drawing.Point(667, 280)
        Me.LabelData18.Name = "LabelData18"
        Me.LabelData18.Size = New System.Drawing.Size(67, 13)
        Me.LabelData18.TabIndex = 333
        Me.LabelData18.Text = "                  0"
        '
        'LabelData17
        '
        Me.LabelData17.AutoSize = True
        Me.LabelData17.Location = New System.Drawing.Point(667, 267)
        Me.LabelData17.Name = "LabelData17"
        Me.LabelData17.Size = New System.Drawing.Size(67, 13)
        Me.LabelData17.TabIndex = 332
        Me.LabelData17.Text = "                  0"
        '
        'LabelData16
        '
        Me.LabelData16.AutoSize = True
        Me.LabelData16.Location = New System.Drawing.Point(667, 254)
        Me.LabelData16.Name = "LabelData16"
        Me.LabelData16.Size = New System.Drawing.Size(67, 13)
        Me.LabelData16.TabIndex = 331
        Me.LabelData16.Text = "                  0"
        '
        'LabelData15
        '
        Me.LabelData15.AutoSize = True
        Me.LabelData15.Location = New System.Drawing.Point(667, 241)
        Me.LabelData15.Name = "LabelData15"
        Me.LabelData15.Size = New System.Drawing.Size(67, 13)
        Me.LabelData15.TabIndex = 330
        Me.LabelData15.Text = "                  0"
        '
        'LabelData14
        '
        Me.LabelData14.AutoSize = True
        Me.LabelData14.Location = New System.Drawing.Point(667, 228)
        Me.LabelData14.Name = "LabelData14"
        Me.LabelData14.Size = New System.Drawing.Size(67, 13)
        Me.LabelData14.TabIndex = 329
        Me.LabelData14.Text = "                  0"
        '
        'LabelData13
        '
        Me.LabelData13.AutoSize = True
        Me.LabelData13.Location = New System.Drawing.Point(667, 215)
        Me.LabelData13.Name = "LabelData13"
        Me.LabelData13.Size = New System.Drawing.Size(67, 13)
        Me.LabelData13.TabIndex = 328
        Me.LabelData13.Text = "                  0"
        '
        'LabelData12
        '
        Me.LabelData12.AutoSize = True
        Me.LabelData12.Location = New System.Drawing.Point(667, 202)
        Me.LabelData12.Name = "LabelData12"
        Me.LabelData12.Size = New System.Drawing.Size(67, 13)
        Me.LabelData12.TabIndex = 327
        Me.LabelData12.Text = "                  0"
        '
        'LabelData11
        '
        Me.LabelData11.AutoSize = True
        Me.LabelData11.Location = New System.Drawing.Point(667, 189)
        Me.LabelData11.Name = "LabelData11"
        Me.LabelData11.Size = New System.Drawing.Size(67, 13)
        Me.LabelData11.TabIndex = 326
        Me.LabelData11.Text = "                  0"
        '
        'LabelData10
        '
        Me.LabelData10.AutoSize = True
        Me.LabelData10.Location = New System.Drawing.Point(667, 176)
        Me.LabelData10.Name = "LabelData10"
        Me.LabelData10.Size = New System.Drawing.Size(67, 13)
        Me.LabelData10.TabIndex = 325
        Me.LabelData10.Text = "                  0"
        '
        'LabelData9
        '
        Me.LabelData9.AutoSize = True
        Me.LabelData9.Location = New System.Drawing.Point(667, 163)
        Me.LabelData9.Name = "LabelData9"
        Me.LabelData9.Size = New System.Drawing.Size(67, 13)
        Me.LabelData9.TabIndex = 324
        Me.LabelData9.Text = "                  0"
        '
        'LabelData8
        '
        Me.LabelData8.AutoSize = True
        Me.LabelData8.Location = New System.Drawing.Point(667, 150)
        Me.LabelData8.Name = "LabelData8"
        Me.LabelData8.Size = New System.Drawing.Size(67, 13)
        Me.LabelData8.TabIndex = 323
        Me.LabelData8.Text = "                  0"
        '
        'LabelData7
        '
        Me.LabelData7.AutoSize = True
        Me.LabelData7.Location = New System.Drawing.Point(667, 137)
        Me.LabelData7.Name = "LabelData7"
        Me.LabelData7.Size = New System.Drawing.Size(67, 13)
        Me.LabelData7.TabIndex = 322
        Me.LabelData7.Text = "                  0"
        '
        'LabelData6
        '
        Me.LabelData6.AutoSize = True
        Me.LabelData6.Location = New System.Drawing.Point(667, 124)
        Me.LabelData6.Name = "LabelData6"
        Me.LabelData6.Size = New System.Drawing.Size(67, 13)
        Me.LabelData6.TabIndex = 321
        Me.LabelData6.Text = "                  0"
        '
        'LabelData5
        '
        Me.LabelData5.AutoSize = True
        Me.LabelData5.Location = New System.Drawing.Point(667, 110)
        Me.LabelData5.Name = "LabelData5"
        Me.LabelData5.Size = New System.Drawing.Size(67, 13)
        Me.LabelData5.TabIndex = 320
        Me.LabelData5.Text = "                  0"
        '
        'LabelData4
        '
        Me.LabelData4.AutoSize = True
        Me.LabelData4.Location = New System.Drawing.Point(667, 97)
        Me.LabelData4.Name = "LabelData4"
        Me.LabelData4.Size = New System.Drawing.Size(67, 13)
        Me.LabelData4.TabIndex = 319
        Me.LabelData4.Text = "                  0"
        '
        'LabelData3
        '
        Me.LabelData3.AutoSize = True
        Me.LabelData3.Location = New System.Drawing.Point(667, 84)
        Me.LabelData3.Name = "LabelData3"
        Me.LabelData3.Size = New System.Drawing.Size(67, 13)
        Me.LabelData3.TabIndex = 318
        Me.LabelData3.Text = "                  0"
        '
        'LabelData2
        '
        Me.LabelData2.AutoSize = True
        Me.LabelData2.Location = New System.Drawing.Point(667, 71)
        Me.LabelData2.Name = "LabelData2"
        Me.LabelData2.Size = New System.Drawing.Size(67, 13)
        Me.LabelData2.TabIndex = 317
        Me.LabelData2.Text = "                  0"
        '
        'LabelData1
        '
        Me.LabelData1.AutoSize = True
        Me.LabelData1.Location = New System.Drawing.Point(667, 57)
        Me.LabelData1.Name = "LabelData1"
        Me.LabelData1.Size = New System.Drawing.Size(67, 13)
        Me.LabelData1.TabIndex = 316
        Me.LabelData1.Text = "                  0"
        '
        'LabelData0
        '
        Me.LabelData0.AutoSize = True
        Me.LabelData0.Location = New System.Drawing.Point(667, 44)
        Me.LabelData0.Name = "LabelData0"
        Me.LabelData0.Size = New System.Drawing.Size(67, 13)
        Me.LabelData0.TabIndex = 315
        Me.LabelData0.Text = "                  0"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(147, 150)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(37, 13)
        Me.Label10.TabIndex = 339
        Me.Label10.Text = "Starts:"
        '
        'LabelStarts
        '
        Me.LabelStarts.AutoSize = True
        Me.LabelStarts.Location = New System.Drawing.Point(221, 150)
        Me.LabelStarts.Name = "LabelStarts"
        Me.LabelStarts.Size = New System.Drawing.Size(67, 13)
        Me.LabelStarts.TabIndex = 340
        Me.LabelStarts.Text = "                  0"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(426, 229)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(69, 13)
        Me.Label11.TabIndex = 341
        Me.Label11.Text = "Sweepmode:"
        '
        'LabelSweepmode
        '
        Me.LabelSweepmode.AutoSize = True
        Me.LabelSweepmode.Location = New System.Drawing.Point(501, 229)
        Me.LabelSweepmode.Name = "LabelSweepmode"
        Me.LabelSweepmode.Size = New System.Drawing.Size(67, 13)
        Me.LabelSweepmode.TabIndex = 342
        Me.LabelSweepmode.Text = "                  0"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(426, 241)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(38, 13)
        Me.Label12.TabIndex = 343
        Me.Label12.Text = "Prena:"
        '
        'LabelPrena
        '
        Me.LabelPrena.AutoSize = True
        Me.LabelPrena.Location = New System.Drawing.Point(501, 241)
        Me.LabelPrena.Name = "LabelPrena"
        Me.LabelPrena.Size = New System.Drawing.Size(67, 13)
        Me.LabelPrena.TabIndex = 344
        Me.LabelPrena.Text = "                  0"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(426, 254)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(41, 13)
        Me.Label13.TabIndex = 345
        Me.Label13.Text = "Cycles:"
        '
        'LabelCycles
        '
        Me.LabelCycles.AutoSize = True
        Me.LabelCycles.Location = New System.Drawing.Point(501, 254)
        Me.LabelCycles.Name = "LabelCycles"
        Me.LabelCycles.Size = New System.Drawing.Size(67, 13)
        Me.LabelCycles.TabIndex = 346
        Me.LabelCycles.Text = "                  0"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(426, 267)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(64, 13)
        Me.Label14.TabIndex = 347
        Me.Label14.Text = "Sequences:"
        '
        'LabelSequences
        '
        Me.LabelSequences.AutoSize = True
        Me.LabelSequences.Location = New System.Drawing.Point(501, 267)
        Me.LabelSequences.Name = "LabelSequences"
        Me.LabelSequences.Size = New System.Drawing.Size(67, 13)
        Me.LabelSequences.TabIndex = 348
        Me.LabelSequences.Text = "                  0"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(426, 280)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(49, 13)
        Me.Label15.TabIndex = 349
        Me.Label15.Text = "Syncout:"
        '
        'LabelSyncout
        '
        Me.LabelSyncout.AutoSize = True
        Me.LabelSyncout.Location = New System.Drawing.Point(501, 280)
        Me.LabelSyncout.Name = "LabelSyncout"
        Me.LabelSyncout.Size = New System.Drawing.Size(67, 13)
        Me.LabelSyncout.TabIndex = 350
        Me.LabelSyncout.Text = "                  0"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(426, 294)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(34, 13)
        Me.Label26.TabIndex = 351
        Me.Label26.Text = "Digio:"
        '
        'LabelDigio
        '
        Me.LabelDigio.AutoSize = True
        Me.LabelDigio.Location = New System.Drawing.Point(501, 293)
        Me.LabelDigio.Name = "LabelDigio"
        Me.LabelDigio.Size = New System.Drawing.Size(67, 13)
        Me.LabelDigio.TabIndex = 352
        Me.LabelDigio.Text = "                  0"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(426, 307)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(40, 13)
        Me.Label27.TabIndex = 353
        Me.Label27.Text = "Digval:"
        '
        'LabelDigval
        '
        Me.LabelDigval.AutoSize = True
        Me.LabelDigval.Location = New System.Drawing.Point(501, 307)
        Me.LabelDigval.Name = "LabelDigval"
        Me.LabelDigval.Size = New System.Drawing.Size(67, 13)
        Me.LabelDigval.TabIndex = 354
        Me.LabelDigval.Text = "                  0"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(426, 320)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(36, 13)
        Me.Label30.TabIndex = 355
        Me.Label30.Text = "Dac0:"
        '
        'LabelDac0
        '
        Me.LabelDac0.AutoSize = True
        Me.LabelDac0.Location = New System.Drawing.Point(501, 320)
        Me.LabelDac0.Name = "LabelDac0"
        Me.LabelDac0.Size = New System.Drawing.Size(67, 13)
        Me.LabelDac0.TabIndex = 356
        Me.LabelDac0.Text = "                  0"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(426, 332)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(36, 13)
        Me.Label42.TabIndex = 357
        Me.Label42.Text = "Dac1:"
        '
        'LabelDac1
        '
        Me.LabelDac1.AutoSize = True
        Me.LabelDac1.Location = New System.Drawing.Point(501, 332)
        Me.LabelDac1.Name = "LabelDac1"
        Me.LabelDac1.Size = New System.Drawing.Size(67, 13)
        Me.LabelDac1.TabIndex = 358
        Me.LabelDac1.Text = "                  0"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(426, 345)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(36, 13)
        Me.Label43.TabIndex = 359
        Me.Label43.Text = "Dac2:"
        '
        'LabelDac2
        '
        Me.LabelDac2.AutoSize = True
        Me.LabelDac2.Location = New System.Drawing.Point(501, 345)
        Me.LabelDac2.Name = "LabelDac2"
        Me.LabelDac2.Size = New System.Drawing.Size(67, 13)
        Me.LabelDac2.TabIndex = 360
        Me.LabelDac2.Text = "                  0"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(426, 358)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(36, 13)
        Me.Label44.TabIndex = 361
        Me.Label44.Text = "Dac3:"
        '
        'LabelDac3
        '
        Me.LabelDac3.AutoSize = True
        Me.LabelDac3.Location = New System.Drawing.Point(501, 359)
        Me.LabelDac3.Name = "LabelDac3"
        Me.LabelDac3.Size = New System.Drawing.Size(67, 13)
        Me.LabelDac3.TabIndex = 362
        Me.LabelDac3.Text = "                  0"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(426, 371)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(36, 13)
        Me.Label45.TabIndex = 363
        Me.Label45.Text = "Dac4:"
        '
        'LabelDac4
        '
        Me.LabelDac4.AutoSize = True
        Me.LabelDac4.Location = New System.Drawing.Point(501, 371)
        Me.LabelDac4.Name = "LabelDac4"
        Me.LabelDac4.Size = New System.Drawing.Size(67, 13)
        Me.LabelDac4.TabIndex = 364
        Me.LabelDac4.Text = "                  0"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(426, 384)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(36, 13)
        Me.Label46.TabIndex = 365
        Me.Label46.Text = "Dac5:"
        '
        'LabelDac5
        '
        Me.LabelDac5.AutoSize = True
        Me.LabelDac5.Location = New System.Drawing.Point(501, 384)
        Me.LabelDac5.Name = "LabelDac5"
        Me.LabelDac5.Size = New System.Drawing.Size(67, 13)
        Me.LabelDac5.TabIndex = 366
        Me.LabelDac5.Text = "                  0"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(426, 397)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(34, 13)
        Me.Label47.TabIndex = 367
        Me.Label47.Text = "Fdac:"
        '
        'LabelFdac
        '
        Me.LabelFdac.AutoSize = True
        Me.LabelFdac.Location = New System.Drawing.Point(501, 397)
        Me.LabelFdac.Name = "LabelFdac"
        Me.LabelFdac.Size = New System.Drawing.Size(67, 13)
        Me.LabelFdac.TabIndex = 368
        Me.LabelFdac.Text = "                  0"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(425, 409)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(45, 13)
        Me.Label48.TabIndex = 369
        Me.Label48.Text = "Tagbits:"
        '
        'LabelTagbits
        '
        Me.LabelTagbits.AutoSize = True
        Me.LabelTagbits.Location = New System.Drawing.Point(501, 409)
        Me.LabelTagbits.Name = "LabelTagbits"
        Me.LabelTagbits.Size = New System.Drawing.Size(67, 13)
        Me.LabelTagbits.TabIndex = 370
        Me.LabelTagbits.Text = "                  0"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(426, 422)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(39, 13)
        Me.Label49.TabIndex = 371
        Me.Label49.Text = "Extclk:"
        '
        'LabelExtclk
        '
        Me.LabelExtclk.AutoSize = True
        Me.LabelExtclk.Location = New System.Drawing.Point(501, 422)
        Me.LabelExtclk.Name = "LabelExtclk"
        Me.LabelExtclk.Size = New System.Drawing.Size(67, 13)
        Me.LabelExtclk.TabIndex = 372
        Me.LabelExtclk.Text = "                  0"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(426, 435)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(38, 13)
        Me.Label50.TabIndex = 373
        Me.Label50.Text = "Serno:"
        '
        'LabelSerno
        '
        Me.LabelSerno.AutoSize = True
        Me.LabelSerno.Location = New System.Drawing.Point(501, 435)
        Me.LabelSerno.Name = "LabelSerno"
        Me.LabelSerno.Size = New System.Drawing.Size(67, 13)
        Me.LabelSerno.TabIndex = 374
        Me.LabelSerno.Text = "                  0"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(426, 448)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(44, 13)
        Me.Label51.TabIndex = 375
        Me.Label51.Text = "Ddruse:"
        '
        'LabelDdruse
        '
        Me.LabelDdruse.AutoSize = True
        Me.LabelDdruse.Location = New System.Drawing.Point(501, 448)
        Me.LabelDdruse.Name = "LabelDdruse"
        Me.LabelDdruse.Size = New System.Drawing.Size(67, 13)
        Me.LabelDdruse.TabIndex = 376
        Me.LabelDdruse.Text = "                  0"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(426, 461)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(53, 13)
        Me.Label52.TabIndex = 377
        Me.Label52.Text = "Holdafter:"
        '
        'LabelHoldafter
        '
        Me.LabelHoldafter.AutoSize = True
        Me.LabelHoldafter.Location = New System.Drawing.Point(501, 461)
        Me.LabelHoldafter.Name = "LabelHoldafter"
        Me.LabelHoldafter.Size = New System.Drawing.Size(67, 13)
        Me.LabelHoldafter.TabIndex = 378
        Me.LabelHoldafter.Text = "                  0"
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(426, 474)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(54, 13)
        Me.Label53.TabIndex = 379
        Me.Label53.Text = "Swpreset:"
        '
        'LabelSwpreset
        '
        Me.LabelSwpreset.AutoSize = True
        Me.LabelSwpreset.Location = New System.Drawing.Point(501, 474)
        Me.LabelSwpreset.Name = "LabelSwpreset"
        Me.LabelSwpreset.Size = New System.Drawing.Size(67, 13)
        Me.LabelSwpreset.TabIndex = 380
        Me.LabelSwpreset.Text = "                  0"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(426, 487)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(54, 13)
        Me.Label55.TabIndex = 381
        Me.Label55.Text = "Acqdelay:"
        '
        'LabelFstchan
        '
        Me.LabelFstchan.AutoSize = True
        Me.LabelFstchan.Location = New System.Drawing.Point(501, 487)
        Me.LabelFstchan.Name = "LabelFstchan"
        Me.LabelFstchan.Size = New System.Drawing.Size(67, 13)
        Me.LabelFstchan.TabIndex = 382
        Me.LabelFstchan.Text = "                  0"
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Location = New System.Drawing.Point(426, 500)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(62, 13)
        Me.Label56.TabIndex = 383
        Me.Label56.Text = "Timepreset:"
        '
        'LabelTimepreset
        '
        Me.LabelTimepreset.AutoSize = True
        Me.LabelTimepreset.Location = New System.Drawing.Point(501, 500)
        Me.LabelTimepreset.Name = "LabelTimepreset"
        Me.LabelTimepreset.Size = New System.Drawing.Size(67, 13)
        Me.LabelTimepreset.TabIndex = 384
        Me.LabelTimepreset.Text = "                  0"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1000
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(762, 574)
        Me.Controls.Add(Me.LabelTimepreset)
        Me.Controls.Add(Me.Label56)
        Me.Controls.Add(Me.LabelFstchan)
        Me.Controls.Add(Me.Label55)
        Me.Controls.Add(Me.LabelSwpreset)
        Me.Controls.Add(Me.Label53)
        Me.Controls.Add(Me.LabelHoldafter)
        Me.Controls.Add(Me.Label52)
        Me.Controls.Add(Me.LabelDdruse)
        Me.Controls.Add(Me.Label51)
        Me.Controls.Add(Me.LabelSerno)
        Me.Controls.Add(Me.Label50)
        Me.Controls.Add(Me.LabelExtclk)
        Me.Controls.Add(Me.Label49)
        Me.Controls.Add(Me.LabelTagbits)
        Me.Controls.Add(Me.Label48)
        Me.Controls.Add(Me.LabelFdac)
        Me.Controls.Add(Me.Label47)
        Me.Controls.Add(Me.LabelDac5)
        Me.Controls.Add(Me.Label46)
        Me.Controls.Add(Me.LabelDac4)
        Me.Controls.Add(Me.Label45)
        Me.Controls.Add(Me.LabelDac3)
        Me.Controls.Add(Me.Label44)
        Me.Controls.Add(Me.LabelDac2)
        Me.Controls.Add(Me.Label43)
        Me.Controls.Add(Me.LabelDac1)
        Me.Controls.Add(Me.Label42)
        Me.Controls.Add(Me.LabelDac0)
        Me.Controls.Add(Me.Label30)
        Me.Controls.Add(Me.LabelDigval)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.LabelDigio)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.LabelSyncout)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.LabelSequences)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.LabelCycles)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.LabelPrena)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.LabelSweepmode)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.LabelStarts)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.LabelData23)
        Me.Controls.Add(Me.LabelData22)
        Me.Controls.Add(Me.LabelData21)
        Me.Controls.Add(Me.LabelData20)
        Me.Controls.Add(Me.LabelData19)
        Me.Controls.Add(Me.LabelData18)
        Me.Controls.Add(Me.LabelData17)
        Me.Controls.Add(Me.LabelData16)
        Me.Controls.Add(Me.LabelData15)
        Me.Controls.Add(Me.LabelData14)
        Me.Controls.Add(Me.LabelData13)
        Me.Controls.Add(Me.LabelData12)
        Me.Controls.Add(Me.LabelData11)
        Me.Controls.Add(Me.LabelData10)
        Me.Controls.Add(Me.LabelData9)
        Me.Controls.Add(Me.LabelData8)
        Me.Controls.Add(Me.LabelData7)
        Me.Controls.Add(Me.LabelData6)
        Me.Controls.Add(Me.LabelData5)
        Me.Controls.Add(Me.LabelData4)
        Me.Controls.Add(Me.LabelData3)
        Me.Controls.Add(Me.LabelData2)
        Me.Controls.Add(Me.LabelData1)
        Me.Controls.Add(Me.LabelData0)
        Me.Controls.Add(Me.LabelCommand)
        Me.Controls.Add(Me.Label40)
        Me.Controls.Add(Me.LabelSpecfile)
        Me.Controls.Add(Me.Label41)
        Me.Controls.Add(Me.LabelMpafilename)
        Me.Controls.Add(Me.Label37)
        Me.Controls.Add(Me.CommandDatasettings)
        Me.Controls.Add(Me.TextChan)
        Me.Controls.Add(Me.CommandGetspec)
        Me.Controls.Add(Me.LabelCalpoints)
        Me.Controls.Add(Me.Label35)
        Me.Controls.Add(Me.LabelActive)
        Me.Controls.Add(Me.Label34)
        Me.Controls.Add(Me.LabelSmpts)
        Me.Controls.Add(Me.Label33)
        Me.Controls.Add(Me.LabelCaluse)
        Me.Controls.Add(Me.Label32)
        Me.Controls.Add(Me.LabelNregions)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.LabelSephead)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.LabelMpafmt)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.LabelBitshift)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.LabelXdim)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.LabelOffset)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.LabelParam)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.LabelAutoinc)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.LabelFmt)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.LabelSavedata)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.LabelAddcal)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.LabelEventpreset)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.LabelRoimax)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.LabelRoimin)
        Me.Controls.Add(Me.Label36)
        Me.Controls.Add(Me.LabelCftfak)
        Me.Controls.Add(Me.Label38)
        Me.Controls.Add(Me.LabelRange)
        Me.Controls.Add(Me.Label39)
        Me.Controls.Add(Me.CommandSetting)
        Me.Controls.Add(Me.LabelMaxval)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.LabelLine13)
        Me.Controls.Add(Me.LabelLine12)
        Me.Controls.Add(Me.LabelLine11)
        Me.Controls.Add(Me.LabelLine10)
        Me.Controls.Add(Me.LabelLine9)
        Me.Controls.Add(Me.LabelLine8)
        Me.Controls.Add(Me.LabelLine7)
        Me.Controls.Add(Me.LabelLine6)
        Me.Controls.Add(Me.LabelLine5)
        Me.Controls.Add(Me.LabelLine4)
        Me.Controls.Add(Me.LabelLine3)
        Me.Controls.Add(Me.LabelLine2)
        Me.Controls.Add(Me.LabelLine1)
        Me.Controls.Add(Me.LabelLine0)
        Me.Controls.Add(Me.CommandGetstring)
        Me.Controls.Add(Me.LabelSweeps)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.LabelRoirate)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.LabelRoisum)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.LabelTotalsum)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.LabelOfls)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.LabelRuntime)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.LabelStarted)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.CommandUpdate)
        Me.Controls.Add(Me.TextRespons)
        Me.Controls.Add(Me.TextCommand)
        Me.Controls.Add(Me.CommandExecute)
        Me.Controls.Add(Me.CommandSave)
        Me.Controls.Add(Me.CommandErase)
        Me.Controls.Add(Me.CommandContinue)
        Me.Controls.Add(Me.CommandHalt)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.CommandStart)
        Me.Controls.Add(Me.TextMC)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "MCS6 Demo"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LabelCommand As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents LabelSpecfile As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents LabelMpafilename As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents CommandDatasettings As System.Windows.Forms.Button
    Friend WithEvents TextChan As System.Windows.Forms.TextBox
    Friend WithEvents CommandGetspec As System.Windows.Forms.Button
    Friend WithEvents LabelCalpoints As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents LabelActive As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents LabelSmpts As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents LabelCaluse As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents LabelNregions As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents LabelSephead As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents LabelMpafmt As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents LabelBitshift As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents LabelXdim As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents LabelOffset As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents LabelParam As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents LabelAutoinc As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents LabelFmt As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents LabelSavedata As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents LabelAddcal As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents LabelEventpreset As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents LabelRoimax As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents LabelRoimin As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents LabelCftfak As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents LabelRange As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents CommandSetting As System.Windows.Forms.Button
    Friend WithEvents LabelMaxval As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents LabelLine13 As System.Windows.Forms.Label
    Friend WithEvents LabelLine12 As System.Windows.Forms.Label
    Friend WithEvents LabelLine11 As System.Windows.Forms.Label
    Friend WithEvents LabelLine10 As System.Windows.Forms.Label
    Friend WithEvents LabelLine9 As System.Windows.Forms.Label
    Friend WithEvents LabelLine8 As System.Windows.Forms.Label
    Friend WithEvents LabelLine7 As System.Windows.Forms.Label
    Friend WithEvents LabelLine6 As System.Windows.Forms.Label
    Friend WithEvents LabelLine5 As System.Windows.Forms.Label
    Friend WithEvents LabelLine4 As System.Windows.Forms.Label
    Friend WithEvents LabelLine3 As System.Windows.Forms.Label
    Friend WithEvents LabelLine2 As System.Windows.Forms.Label
    Friend WithEvents LabelLine1 As System.Windows.Forms.Label
    Friend WithEvents LabelLine0 As System.Windows.Forms.Label
    Friend WithEvents CommandGetstring As System.Windows.Forms.Button
    Friend WithEvents LabelSweeps As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents LabelRoirate As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents LabelRoisum As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents LabelTotalsum As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents LabelOfls As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents LabelRuntime As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents LabelStarted As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents CommandUpdate As System.Windows.Forms.Button
    Friend WithEvents TextRespons As System.Windows.Forms.TextBox
    Friend WithEvents TextCommand As System.Windows.Forms.TextBox
    Friend WithEvents CommandExecute As System.Windows.Forms.Button
    Friend WithEvents CommandSave As System.Windows.Forms.Button
    Friend WithEvents CommandErase As System.Windows.Forms.Button
    Friend WithEvents CommandContinue As System.Windows.Forms.Button
    Friend WithEvents CommandHalt As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents CommandStart As System.Windows.Forms.Button
    Friend WithEvents TextMC As System.Windows.Forms.TextBox
    Friend WithEvents LabelData23 As System.Windows.Forms.Label
    Friend WithEvents LabelData22 As System.Windows.Forms.Label
    Friend WithEvents LabelData21 As System.Windows.Forms.Label
    Friend WithEvents LabelData20 As System.Windows.Forms.Label
    Friend WithEvents LabelData19 As System.Windows.Forms.Label
    Friend WithEvents LabelData18 As System.Windows.Forms.Label
    Friend WithEvents LabelData17 As System.Windows.Forms.Label
    Friend WithEvents LabelData16 As System.Windows.Forms.Label
    Friend WithEvents LabelData15 As System.Windows.Forms.Label
    Friend WithEvents LabelData14 As System.Windows.Forms.Label
    Friend WithEvents LabelData13 As System.Windows.Forms.Label
    Friend WithEvents LabelData12 As System.Windows.Forms.Label
    Friend WithEvents LabelData11 As System.Windows.Forms.Label
    Friend WithEvents LabelData10 As System.Windows.Forms.Label
    Friend WithEvents LabelData9 As System.Windows.Forms.Label
    Friend WithEvents LabelData8 As System.Windows.Forms.Label
    Friend WithEvents LabelData7 As System.Windows.Forms.Label
    Friend WithEvents LabelData6 As System.Windows.Forms.Label
    Friend WithEvents LabelData5 As System.Windows.Forms.Label
    Friend WithEvents LabelData4 As System.Windows.Forms.Label
    Friend WithEvents LabelData3 As System.Windows.Forms.Label
    Friend WithEvents LabelData2 As System.Windows.Forms.Label
    Friend WithEvents LabelData1 As System.Windows.Forms.Label
    Friend WithEvents LabelData0 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents LabelStarts As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents LabelSweepmode As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents LabelPrena As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents LabelCycles As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents LabelSequences As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents LabelSyncout As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents LabelDigio As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents LabelDigval As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents LabelDac0 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents LabelDac1 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents LabelDac2 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents LabelDac3 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents LabelDac4 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents LabelDac5 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents LabelFdac As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents LabelTagbits As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents LabelExtclk As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents LabelSerno As System.Windows.Forms.Label
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents LabelDdruse As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents LabelHoldafter As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents LabelSwpreset As System.Windows.Forms.Label
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents LabelFstchan As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents LabelTimepreset As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer

End Class
